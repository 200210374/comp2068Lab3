/**
 * Created by Brandon Roy on 21/10/2016.
 *
 */


module.exports = {
    db: 'mongodb://localhost/3000/players'

};